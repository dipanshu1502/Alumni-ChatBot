import os
import re
from functools import lru_cache

import requests

BASE_URL = (os.getenv("CI4_API_BASE_URL") or "http://localhost:8080/api").rstrip("/")

SAFE_FIELDS = {
    "events": [
        "title",
        "slug",
        "event_type",
        "department",
        "description",
        "venue",
        "start_datetime",
        "end_datetime",
        "registration_deadline",
    ],
    "alumni": [
        "display_name",
        "name",
        "degree",
        "department",
        "graduation_year",
        "batch",
        "company",
        "designation",
        "city",
        "country",
        "skills",
        "bio",
    ],
    "jobs": [
        "job_title",
        "title",
        "company",
        "location",
        "job_type",
        "description",
        "eligibility",
        "application_deadline",
        "application_instructions",
    ],
    "chapters": [
        "name",
        "title",
        "location",
        "chapter_type",
        "description",
        "city",
        "country",
    ],
    "stories": [
        "title",
        "headline",
        "summary",
        "description",
        "author",
        "published_at",
    ],
    "news": [
        "title",
        "summary",
        "description",
        "published_at",
    ],
    "gallery": [
        "title",
        "caption",
        "category",
        "image_url",
    ],
    "donations": [
        "title",
        "campaign_name",
        "description",
        "goal_amount",
        "raised_amount",
        "deadline",
    ],
    "settings": ["title", "name", "value", "description"],
    "stats": ["label", "value", "description"],
}

ENDPOINT_KEYWORDS = {
    "events": ["event", "seminar", "workshop", "conference", "upcoming", "campus", "program"],
    "jobs": ["job", "jobs", "opportunity", "opportunities", "oppurtunity", "oppportunities", "career", "placement", "recruitment", "internship", "hiring"],
    "alumni": ["alumni", "graduate", "alumnus", "batch", "alumni profile"],
    "chapters": ["chapter", "alumni chapter", "network", "association"],
    "stories": ["story", "success story", "achievement", "testimonial"],
    "news": ["news", "announcement", "update", "notice"],
    "gallery": ["gallery", "photo", "image", "picture"],
    "donations": ["donation", "fund", "campaign", "support"],
    "stats": ["total alumni", "number of alumni", "alumni count", "how many alumni", "total students", "student count", "total events", "total jobs", "total chapters", "statistics", "stats"],
}

ENDPOINT_QUERY_PARAMS = {
    "events": {"filter": "upcoming"},
}


@lru_cache(maxsize=1)
def get_public_endpoints():
    return [
        "public/settings",
        "public/stats",
        "public/alumni",
        "public/events",
        "public/jobs",
        "public/chapters",
        "public/stories",
        "public/news",
        "public/gallery",
        "public/donations",
    ]


def detect_language(text):
    if not text:
        return "english"
    hindi_matches = re.findall(r"[\u0900-\u097F]", text)
    if hindi_matches:
        return "hindi"
    if any(token in text.lower() for token in ["namaste", "kaise", "hai", "aap", "kya", "sabse"]):
        return "hinglish"
    return "english"


def _safe_value(value):
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (int, float, bool)):
        return value
    return value


def _normalize_payload(payload):
    if isinstance(payload, dict):
        for key in ("data", "result", "items", "records"):
            if key in payload and payload[key] is not None:
                return _normalize_payload(payload[key])
        return payload
    if isinstance(payload, list):
        return payload
    return []


def _filter_public_fields(endpoint_name, item):
    if not isinstance(item, dict):
        return {}
    allowed = SAFE_FIELDS.get(endpoint_name, [])
    if not allowed:
        return {k: _safe_value(v) for k, v in item.items() if k not in {"id", "user_id", "created_by", "updated_by", "internal_notes"}}

    filtered = {}
    alias_map = {
        "display_name": "display_name",
        "name": "name",
        "job_title": "job_title",
        "title": "title",
        "slug": "slug",
        "degree": "degree",
        "department": "department",
        "graduation_year": "graduation_year",
        "batch": "batch",
        "company": "company",
        "designation": "designation",
        "city": "city",
        "country": "country",
        "skills": "skills",
        "bio": "bio",
        "description": "description",
        "event_type": "event_type",
        "venue": "venue",
        "start_datetime": "start_datetime",
        "end_datetime": "end_datetime",
        "registration_deadline": "registration_deadline",
        "location": "location",
        "job_type": "job_type",
        "eligibility": "eligibility",
        "application_deadline": "application_deadline",
        "application_instructions": "application_instructions",
        "chapter_type": "chapter_type",
        "published_at": "published_at",
        "image_url": "image_url",
        "goal_amount": "goal_amount",
        "raised_amount": "raised_amount",
        "deadline": "deadline",
    }

    for key in allowed:
        value = None
        for candidate in (key, alias_map.get(key)):
            if candidate and candidate in item:
                value = item[candidate]
                break
        if value is not None:
            filtered[key] = _safe_value(value)
    return filtered


def _extract_records(payload, endpoint_name):
    if endpoint_name == "stats" and isinstance(payload, dict):
        stats = payload.get("data", payload)
        if isinstance(stats, dict):
            counts = stats.get("counts", {})
            return [{"category": "counts", **counts}] if isinstance(counts, dict) else []

    normalized = _normalize_payload(payload)
    if isinstance(normalized, dict):
        records = [normalized]
    else:
        records = normalized

    if not isinstance(records, list):
        return []

    filtered = []
    for record in records:
        safe_item = _filter_public_fields(endpoint_name, record)
        if safe_item:
            filtered.append(safe_item)
    return filtered


def fetch_public_endpoint(endpoint_name, params=None, limit=5):
    if not endpoint_name.startswith("public/"):
        endpoint_name = f"public/{endpoint_name.lstrip('/')}"

    url = f"{BASE_URL}/{endpoint_name}"
    try:
        response = requests.get(url, params=params or {}, timeout=10)
        response.raise_for_status()
        data = response.json()
    except requests.RequestException:
        return [], f"Live alumni data for {endpoint_name} is temporarily unavailable."
    except ValueError:
        return [], f"Live alumni data for {endpoint_name} is temporarily unavailable."

    records = _extract_records(data, endpoint_name.split("/")[-1])
    if limit and records:
        return records[:limit], None
    return records, None


def classify_question(question):
    q = (question or "").lower()
    q = q.replace("upcomming", "upcoming").replace("enevts", "events").replace("alumnis", "alumni")

    if not q:
        return []

    stats_terms = ("total alumni", "number of alumni", "alumni count", "how many alumni", "total students", "student count", "total events", "total jobs", "total chapters", "statistics", "stats")
    if any(term in q for term in stats_terms):
        return ["stats"]

    matched = []
    for endpoint, keywords in ENDPOINT_KEYWORDS.items():
        if any(keyword in q for keyword in keywords):
            matched.append(endpoint)

    if not matched:
        return ["documents"]
    return matched


def _record_search_text(record):
    return " ".join(str(value) for value in record.values() if value not in (None, "", [], {})).lower()


def _question_terms(question):
    ignored = {"what", "when", "where", "which", "who", "tell", "about", "show", "find", "give", "there", "any", "the", "for", "from", "with", "and", "are", "is", "was", "were", "upcoming", "upcomming", "past", "previous", "old", "ended", "event", "events", "enevts", "alumni", "alumnis", "alumnus", "graduate", "graduates", "opportunity", "opportunities", "oppurtunity", "oppportunities", "jobs", "job", "total", "number", "count", "many", "statistics", "stats"}
    q = (question or "").lower().replace("upcomming", "upcoming").replace("enevts", "events").replace("alumnis", "alumni")
    return [term for term in re.findall(r"[a-z0-9]+", q) if len(term) > 2 and term not in ignored]


def _rank_records(question, records, limit):
    terms = _question_terms(question)
    if not terms:
        return records[:limit] if limit else records

    ranked = []
    for record in records:
        text = _record_search_text(record)
        score = sum(2 if re.search(rf"\b{re.escape(term)}\b", text) else 0 for term in terms)
        score += sum(1 for term in terms if term in text)
        ranked.append((score, record))
    ranked.sort(key=lambda pair: pair[0], reverse=True)
    matching = [record for score, record in ranked if score > 0]
    # If the question has meaningful terms but no records match, return no
    # evidence instead of unrelated first-page rows.
    selected = matching if matching else []
    return selected[:limit] if limit else selected


def fetch_relevant_portal_data(question, limit_per_endpoint=3):
    matched_endpoints = classify_question(question)
    portal_items = []
    for endpoint in matched_endpoints:
        if endpoint == "documents":
            continue
        params = dict(ENDPOINT_QUERY_PARAMS.get(endpoint, {}))
        terms = _question_terms(question)
        if endpoint == "events":
            q = question.lower().replace("upcomming", "upcoming").replace("enevts", "events")
            if any(term in q for term in ("past", "previous", "old", "ended")):
                params["filter"] = "past"
            else:
                params["filter"] = "upcoming"
        records, error = fetch_public_endpoint(endpoint, params=params, limit=0)
        if error:
            portal_items.append({"source": endpoint, "error": error})
            continue
        for item in _rank_records(question, records, limit_per_endpoint):
            portal_items.append({"source": endpoint, "data": item})
    return portal_items


def summarize_portal_items(question, portal_items):
    if not portal_items:
        return None

    text_chunks = []
    for item in portal_items[:6]:
        source = item.get("source", "portal")
        record = item.get("data", {})
        if not record:
            continue
        values = [f"{key}: {value}" for key, value in record.items() if value not in (None, "", [], {})]
        if values:
            text_chunks.append(f"{source} -> {'; '.join(values[:8])}")

    if not text_chunks:
        return None

    context = "\n".join(text_chunks)
    return (
        f"The user asked: {question}\n\nUse only the live alumni portal context below. "
        "If the portal information is missing or unavailable, say so clearly.\n\n{context}"
    )
